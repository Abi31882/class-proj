// Auth
export const ME_FETCH = "me/fetch";
export const ME_LOGIN = "me/login";

// Groups
export const GROUPS_QUERY = "groups/query";
export const GROUPS_QUERY_COMPLETED = "groups/query_completed";
