import { lazy } from "react";

const AppContainerPageLazy = lazy(() => import("./AppContainer.page"));

export default AppContainerPageLazy;
