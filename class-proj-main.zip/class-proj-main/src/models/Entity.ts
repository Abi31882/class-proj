export interface Entity {
  id: number;
}
